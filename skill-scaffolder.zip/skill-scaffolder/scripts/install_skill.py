#!/usr/bin/env python3
"""
install_skill.py — OpenClaw Skill Installer
============================================
Copies a scaffolded skill from a temp directory into the OpenClaw skills folder.

Usage:
    python install_skill.py --source /tmp/scaffolded-skills/my-skill/ --name my-skill

The installer:
1. Validates the skill package (checks SKILL.md exists and frontmatter is valid)
2. Checks for naming conflicts and prompts before overwriting
3. Copies all files to the skills directory
4. Reports success in plain English
"""

import argparse
import os
import re
import shutil
import sys

# ── Default skills directory (override with --skills-dir) ─────────────────────
DEFAULT_SKILLS_DIR = os.path.expanduser("~/.openclaw/skills")


def find_skills_dir():
    """Try to locate the OpenClaw skills directory."""
    candidates = [
        os.path.expanduser("~/.openclaw/skills"),
        os.path.expanduser("~/Library/Application Support/OpenClaw/skills"),  # macOS
        os.path.join(os.environ.get("APPDATA", ""), "OpenClaw", "skills"),   # Windows
        "/etc/openclaw/skills",
    ]
    for path in candidates:
        if os.path.isdir(path):
            return path
    return DEFAULT_SKILLS_DIR


def validate_skill(source_dir: str) -> list[str]:
    """Returns a list of validation errors (empty = all good)."""
    errors = []
    skill_md = os.path.join(source_dir, "SKILL.md")

    if not os.path.exists(skill_md):
        errors.append("SKILL.md is missing from the skill folder.")
        return errors

    with open(skill_md) as f:
        content = f.read()

    if not (content.startswith("---") and content.count("---") >= 2):
        errors.append("SKILL.md is missing its settings block (YAML frontmatter).")

    if not re.search(r'^name:\s+\S+', content, re.MULTILINE):
        errors.append("SKILL.md is missing a 'name' field.")

    if not re.search(r'^description:', content, re.MULTILINE):
        errors.append("SKILL.md is missing a 'description' field.")

    return errors


def install(source_dir: str, skill_name: str, skills_dir: str, force: bool = False):
    target_dir = os.path.join(skills_dir, skill_name)

    # ── Validate ────────────────────────────────────────────────────────────
    errors = validate_skill(source_dir)
    if errors:
        print("\n❌  The skill has some issues that need to be fixed first:\n")
        for e in errors:
            print(f"   • {e}")
        print("\nPlease fix these and try again.")
        sys.exit(1)

    # ── Conflict check ──────────────────────────────────────────────────────
    if os.path.exists(target_dir) and not force:
        print(f"\n⚠️   A skill named '{skill_name}' is already installed.")
        answer = input("   Replace it with the new version? [y/N] ").strip().lower()
        if answer != "y":
            print("   Installation cancelled. Your existing skill is unchanged.")
            sys.exit(0)
        shutil.rmtree(target_dir)

    # ── Install ─────────────────────────────────────────────────────────────
    os.makedirs(skills_dir, exist_ok=True)
    shutil.copytree(source_dir, target_dir)

    # Count installed files
    file_count = sum(len(files) for _, _, files in os.walk(target_dir))

    print(f"\n✅  Skill '{skill_name}' installed successfully!")
    print(f"   Location : {target_dir}")
    print(f"   Files    : {file_count}")
    print(f"\n🚀  Claude will now use this skill automatically.")
    print(f"   Try it by describing what you want — no special command needed.\n")


def main():
    parser = argparse.ArgumentParser(
        description="Install a scaffolded OpenClaw skill."
    )
    parser.add_argument("--source", required=True,
                        help="Path to the scaffolded skill directory")
    parser.add_argument("--name", required=True,
                        help="Skill name (used as the folder name)")
    parser.add_argument("--skills-dir", default=None,
                        help="Override the default skills directory")
    parser.add_argument("--force", action="store_true",
                        help="Overwrite existing skill without prompting")

    args = parser.parse_args()

    skills_dir = args.skills_dir or find_skills_dir()
    source_dir = os.path.abspath(args.source)

    if not os.path.isdir(source_dir):
        print(f"\n❌  Source directory not found: {source_dir}")
        sys.exit(1)

    install(
        source_dir=source_dir,
        skill_name=args.name,
        skills_dir=skills_dir,
        force=args.force,
    )


if __name__ == "__main__":
    main()
