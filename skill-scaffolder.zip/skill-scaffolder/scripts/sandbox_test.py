#!/usr/bin/env python3
"""
sandbox_test.py — OpenClaw Skill Sandbox Test Runner
=====================================================
Auto-detects what's in a skill package and runs appropriate structural and
functional checks. Produces a plain-English pass/fail report.

Usage:
    python sandbox_test.py [--skill-dir /path/to/skill]

If --skill-dir is not provided, defaults to the parent of this script's directory
(i.e., the skill folder this script lives in).
"""

import argparse
import ast
import os
import re
import subprocess
import sys

results = []
warnings = []


def test(name: str, condition: bool, detail: str = "") -> None:
    status = "✅ PASS" if condition else "❌ FAIL"
    msg = f"  {status}  {name}"
    if not condition and detail:
        msg += f"\n          → {detail}"
    print(msg)
    results.append(condition)


def warn(message: str) -> None:
    print(f"  ⚠️  NOTE  {message}")
    warnings.append(message)


def check_frontmatter(content: str) -> dict:
    """Extract key-value pairs from YAML frontmatter."""
    info = {}
    if not content.startswith("---"):
        return info
    end = content.find("---", 3)
    if end == -1:
        return info
    block = content[3:end]
    for line in block.splitlines():
        m = re.match(r'^(\w[\w-]*):\s*(.+)', line)
        if m:
            info[m.group(1).strip()] = m.group(2).strip()
    return info


def run_checks(skill_dir: str) -> None:
    skill_md_path = os.path.join(skill_dir, "SKILL.md")
    scripts_dir = os.path.join(skill_dir, "scripts")
    references_dir = os.path.join(skill_dir, "references")
    assets_dir = os.path.join(skill_dir, "assets")

    print("\n── Structure Checks ──────────────────────────────────────────────")

    # 1. SKILL.md exists
    test("SKILL.md exists",
         os.path.exists(skill_md_path),
         "The main skill file is missing.")

    if not os.path.exists(skill_md_path):
        print("\n  Cannot continue without SKILL.md. Stopping.")
        return

    with open(skill_md_path) as f:
        content = f.read()

    # 2. Frontmatter block
    has_fm = content.startswith("---") and content.count("---") >= 2
    test("SKILL.md has a settings block (frontmatter)",
         has_fm,
         "The file should start with --- and have a matching closing ---.")

    fm = check_frontmatter(content)

    # 3. name field
    test("SKILL.md has a 'name' field",
         "name" in fm and len(fm["name"]) > 0,
         "Add  name: your-skill-name  to the settings block.")

    # 4. description field
    has_desc = bool(re.search(r'^description:', content, re.MULTILINE))
    test("SKILL.md has a 'description' field",
         has_desc,
         "Add  description: ...  to the settings block.")

    # 5. Description quality hints
    if has_desc:
        desc_match = re.search(r'^description:\s*(.+?)(?=^[a-z]|\Z)', content,
                                re.MULTILINE | re.DOTALL)
        if desc_match:
            desc_text = desc_match.group(1).strip().lstrip(">").strip()
            word_count = len(desc_text.split())
            if word_count < 20:
                warn("Description is quite short (under 20 words). "
                     "A more detailed description helps Claude know when to use the skill.")
            trigger_phrases = re.findall(r'"[^"]+"', desc_text)
            if len(trigger_phrases) == 0:
                warn("Description doesn't include any quoted trigger phrases. "
                     "Adding phrases like \"make me a skill\" helps Claude activate it reliably.")

    # 6. Body has content
    body_start = content.find("---", 3)
    body = content[body_start + 3:].strip() if body_start != -1 else ""
    test("SKILL.md has a body (instructions)",
         len(body) > 100,
         "The skill body is too short — add a workflow or instructions section.")

    print("\n── Script Checks ─────────────────────────────────────────────────")

    scripts = []
    if os.path.isdir(scripts_dir):
        scripts = [f for f in os.listdir(scripts_dir) if f.endswith(".py")
                   and f != "sandbox_test.py" and f != "install_skill.py"]

    if not scripts:
        print("  (no helper scripts found — skipping script checks)")
    else:
        for script_name in scripts:
            script_path = os.path.join(scripts_dir, script_name)

            # Exists
            test(f"Script exists: {script_name}", os.path.exists(script_path))

            # Valid Python syntax
            if os.path.exists(script_path):
                with open(script_path) as f:
                    src = f.read()
                try:
                    ast.parse(src)
                    syntax_ok = True
                    err_msg = ""
                except SyntaxError as e:
                    syntax_ok = False
                    err_msg = f"Line {e.lineno}: {e.msg}"
                test(f"Script has valid syntax: {script_name}",
                     syntax_ok, err_msg)

                # Has docstring
                has_docstring = src.strip().startswith('"""') or \
                                src.strip().startswith("'''") or \
                                '"""' in src[:300]
                if not has_docstring:
                    warn(f"{script_name} has no docstring — "
                         "add one to explain what the script does.")

    print("\n── Reference & Asset Checks ──────────────────────────────────────")

    # Check that files referenced in SKILL.md actually exist
    # Strip fenced code blocks so we don't flag *example* paths inside them
    body_no_fences = re.sub(r"```.*?```", "", body, flags=re.DOTALL)
    # Also strip indented code blocks (4-space / tab indent lines)
    body_no_fences = re.sub(r"(?m)^( {4}|	).+", "", body_no_fences)
    BACKTICK_REF = re.compile(r"`((?:references|assets|scripts)/[^`]+)`")
    referenced_files = BACKTICK_REF.findall(body_no_fences)
    if not referenced_files:
        print("  (no bundled file references found in SKILL.md)")
    else:
        for ref in set(referenced_files):
            ref_path = os.path.join(skill_dir, ref)
            test(f"Referenced file exists: {ref}",
                 os.path.exists(ref_path),
                 f"SKILL.md references this file but it wasn't found at: {ref_path}")

    print("\n── Placeholder Check ─────────────────────────────────────────────")

    # Look for unfilled template placeholders
    placeholders = re.findall(r'[A-Z_]{4,}', body)
    IGNORE = {
        "TODO", "NOTE", "YAML", "ASCII", "README", "PASS", "FAIL", "HTML",
        "JSON", "CSV", "PDF", "SKILL", "PHASE", "STEP", "ALWAYS", "NEVER",
        "ONLY", "WHEN", "OPEN", "SHOW", "SKIP", "SAVE", "READ", "LOAD",
        "PATH", "FILE", "NAME", "TYPE", "USER", "TOOL", "LIST", "MARK",
        "NEXT", "LAST", "FULL", "MAIN", "BASE", "TEMP", "AUTO", "ONCE",
    }
    placeholder_words = {p for p in placeholders if p not in IGNORE}
    if placeholder_words:
        warn(f"Possible unfilled template placeholders: "
             f"{', '.join(sorted(placeholder_words)[:5])}")
        test("No template placeholders remaining",
             len(placeholder_words) == 0,
             "Replace ALL_CAPS_PLACEHOLDER words with real content.")
    else:
        test("No template placeholders remaining", True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--skill-dir", default=None,
                        help="Path to the skill directory to test")
    args = parser.parse_args()

    if args.skill_dir:
        skill_dir = os.path.abspath(args.skill_dir)
    else:
        # Default: parent directory of this script
        skill_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    if not os.path.isdir(skill_dir):
        print(f"\n❌  Skill directory not found: {skill_dir}")
        sys.exit(1)

    skill_name = os.path.basename(skill_dir)
    print(f"\n{'='*58}")
    print(f"  Sandbox Test — {skill_name}")
    print(f"  Directory: {skill_dir}")
    print(f"{'='*58}")

    run_checks(skill_dir)

    passed = sum(results)
    total = len(results)
    all_passed = passed == total

    print(f"\n{'='*58}")
    if all_passed:
        print(f"  ✅  All {total} checks passed!")
        if warnings:
            print(f"  ⚠️   {len(warnings)} suggestion(s) — see notes above")
        print(f"\n  This skill looks ready to install.")
    else:
        failed = total - passed
        print(f"  ❌  {failed} check(s) failed  ({passed}/{total} passed)")
        print(f"\n  Please fix the issues above before installing.")

    print(f"{'='*58}\n")
    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
