# Sandbox Test Patterns

This reference contains copy-paste patterns for generating `sandbox_test.py` scripts.
Pick the patterns that match the skill being tested. Combine multiple patterns as needed.

Every sandbox test should:
1. Run in under 10 seconds
2. Require no user input
3. Print a clear PASS / FAIL per test
4. Print a final summary line: "X/Y tests passed"
5. Exit with code 0 if all pass, code 1 if any fail

---

## Boilerplate (always include)

```python
#!/usr/bin/env python3
"""
Sandbox test for: <skill-name>
Runs lightweight checks to verify the skill is correctly structured
and its helper scripts (if any) work as expected.
No internet access or user input required.
"""

import sys
import os

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
results = []

def test(name, condition, detail=""):
    status = "PASS" if condition else "FAIL"
    msg = f"[{status}] {name}"
    if not condition and detail:
        msg += f"\n       → {detail}"
    print(msg)
    results.append(condition)

# ─── TESTS GO HERE ────────────────────────────────────────────────────────────

# ─── SUMMARY ──────────────────────────────────────────────────────────────────
passed = sum(results)
total = len(results)
print(f"\n{'='*40}")
print(f"  {passed}/{total} tests passed")
print(f"{'='*40}")
sys.exit(0 if passed == total else 1)
```

---

## Pattern A — Structural checks (always include)

Tests that required files exist and the SKILL.md is well-formed.

```python
import re

# Test 1: SKILL.md exists
test(
    "SKILL.md exists",
    os.path.exists(os.path.join(SKILL_DIR, "SKILL.md")),
    "SKILL.md is missing from the skill folder"
)

# Test 2: SKILL.md has frontmatter
with open(os.path.join(SKILL_DIR, "SKILL.md")) as f:
    content = f.read()

has_frontmatter = content.startswith("---") and content.count("---") >= 2
test(
    "SKILL.md has YAML frontmatter",
    has_frontmatter,
    "SKILL.md must start with --- and contain a closing ---"
)

# Test 3: name field present
has_name = bool(re.search(r'^name:\s+\S+', content, re.MULTILINE))
test(
    "SKILL.md has a 'name' field",
    has_name,
    "Add 'name: your-skill-name' to the frontmatter"
)

# Test 4: description field present and non-empty
has_desc = bool(re.search(r'^description:', content, re.MULTILINE))
test(
    "SKILL.md has a 'description' field",
    has_desc,
    "Add 'description: ...' to the frontmatter"
)
```

---

## Pattern B — Script existence check (if helper script included)

```python
SCRIPT_PATH = os.path.join(SKILL_DIR, "scripts", "run.py")

test(
    "Helper script exists",
    os.path.exists(SCRIPT_PATH),
    f"Expected script at: {SCRIPT_PATH}"
)

# Test that it's valid Python
if os.path.exists(SCRIPT_PATH):
    import ast
    with open(SCRIPT_PATH) as f:
        src = f.read()
    try:
        ast.parse(src)
        valid_python = True
    except SyntaxError as e:
        valid_python = False
    test(
        "Helper script is valid Python",
        valid_python,
        str(e) if not valid_python else ""
    )
```

---

## Pattern C — Script smoke test with mock input

Use when the helper script accepts text and returns text.

```python
import subprocess

result = subprocess.run(
    [sys.executable, SCRIPT_PATH, "--input", "test input here"],
    capture_output=True, text=True, timeout=10
)
test(
    "Helper script runs without errors",
    result.returncode == 0,
    result.stderr.strip()[:200] if result.returncode != 0 else ""
)
test(
    "Helper script produces output",
    len(result.stdout.strip()) > 0,
    "Script ran successfully but produced no output"
)
```

---

## Pattern D — File transform smoke test

Use when the skill reads a file and writes a transformed file.

```python
import tempfile

# Create a temp input file
with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
    f.write("Sample input for testing\nLine 2\nLine 3")
    input_path = f.name

output_path = input_path + ".out"

result = subprocess.run(
    [sys.executable, SCRIPT_PATH, "--input", input_path, "--output", output_path],
    capture_output=True, text=True, timeout=15
)

test(
    "Script processes a file without crashing",
    result.returncode == 0,
    result.stderr.strip()[:200]
)
test(
    "Script produces an output file",
    os.path.exists(output_path),
    "Output file was not created"
)

# Cleanup
os.unlink(input_path)
if os.path.exists(output_path):
    os.unlink(output_path)
```

---

## Pattern E — Reference files check

Use when the skill references files in `references/`.

```python
REFERENCES = [
    "references/domain-knowledge.md",  # ← adjust to actual filenames
]

for ref in REFERENCES:
    path = os.path.join(SKILL_DIR, ref)
    test(
        f"Reference file exists: {ref}",
        os.path.exists(path),
        f"Missing file: {path}"
    )
```

---

## Interpreting Common Failures (for the scaffolder to translate)

| Error | Plain-English translation |
|-------|--------------------------|
| `FileNotFoundError: SKILL.md` | The main skill file is missing — likely a path issue |
| `SyntaxError in run.py` | The helper script has a typo or formatting mistake |
| `returncode != 0` + stderr shows `ModuleNotFoundError` | A Python library isn't installed |
| `returncode != 0` + stderr shows `Permission denied` | The script isn't marked as executable |
| Script runs but output is empty | The script ran fine but produced nothing — check the logic |
