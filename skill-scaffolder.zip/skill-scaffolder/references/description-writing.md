# Description Writing Guide

The `description` field in a skill's YAML frontmatter is the **most important part of
the skill** — it controls when Claude decides to use it. A weak description means the
skill never triggers. A strong description means Claude reaches for the skill exactly
when the user needs it.

---

## The Anatomy of a Strong Description

A well-written description has three parts:

### 1. Core action (1 sentence)
What does this skill do? Be specific and verb-first.

✅ `Transforms raw meeting notes into structured action-item summaries with owners and deadlines.`
❌ `Helps with meeting notes.`

### 2. Trigger contexts (1–3 sentences)
When should Claude use this skill? List specific phrases or situations.

✅ `Use whenever the user pastes meeting notes, says "summarize my meeting", "write up
our call", "extract action items", or shares any transcript or notes from a discussion.`
❌ `Use for meeting-related tasks.`

### 3. Push sentence (1 sentence)
Encourage Claude to use the skill proactively, even without an explicit ask.

✅ `If the user pastes anything that looks like meeting notes, activate this skill
automatically — don't wait for them to ask.`
❌ (nothing — many skills are missing this entirely)

---

## Patterns That Work

### Explicit trigger phrase list
> `Activate when user says: "make a skill", "build me a tool", "I want Claude to
> automatically...", "teach Claude to...", "create a workflow for..."`

### Context-first trigger
> `Use when the user uploads a CSV, Excel file, or any tabular data and asks for
> analysis, cleaning, transformation, or visualization.`

### Negative scope (what NOT to trigger on)
> `Do NOT trigger for general writing tasks — only activate when the user explicitly
> mentions their brand voice, tone guide, or company style.`

---

## Anti-Patterns to Avoid

| ❌ Weak | ✅ Strong |
|---------|----------|
| "Helps with emails" | "Drafts, rewrites, and improves emails. Triggers on: 'write an email', 'help me reply to this', 'can you email [person] about...'" |
| "For data tasks" | "Cleans, transforms, and analyzes spreadsheet data. Use whenever a .csv, .xlsx, or tabular data is mentioned." |
| "Use when needed" | "Activate proactively whenever the user's request involves [specific context]." |
| Starting with "A skill that..." | Start with a verb: "Generates...", "Transforms...", "Summarizes..." |

---

## Length Guidelines

- Minimum: 3 sentences (action + triggers + push)
- Maximum: ~8 sentences / ~120 words
- Don't pad — a tight 4-sentence description often beats a rambling 8-sentence one

---

## Quick Test

After writing a description, ask yourself:
1. If a stranger read only this description, would they know exactly when to use the skill?
2. Does it include at least two specific trigger phrases?
3. Does it have a push sentence that encourages proactive use?
4. Is the first word a verb?

If all four are yes, the description is ready.
