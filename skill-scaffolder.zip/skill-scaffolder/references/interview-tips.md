# Interview Tips for Skill Scaffolder

Use this reference when the user is being vague, giving one-word answers, or seems
unsure what they want. The goal is to understand their workflow well enough to build a
skill that actually fits their life — not a generic template.

---

## When the user says something vague

**"I want a skill for writing"**
→ Ask: "What kind of writing? For example — emails, reports, social media posts,
something else?"

**"Make me a productivity skill"**
→ Ask: "What's one thing you do repeatedly that feels slow or annoying right now?
Let's start there."

**"I want Claude to be smarter about [topic]"**
→ Ask: "When you think about Claude working on [topic], what's the one thing you
wish it would do differently or automatically?"

**"Something like [other AI tool]"**
→ Ask: "What's the specific feature of [tool] you love most? Let's build exactly that."

---

## Uncovering the real trigger

Users often don't know how to articulate when they'd use a skill. Try:
- "Walk me through the last time you wished Claude could do this. What did you type?"
- "If you had a magic word that made Claude do this perfectly, what would it be?"
- "Would you use this every day, once a week, or just for special projects?"

---

## Uncovering inputs and outputs

Users often forget to mention what they'd give Claude:
- "Would you paste text into the chat, upload a file, or just ask Claude directly?"
- "When Claude finishes, would you want a file to download, a message in chat, or
  both?"
- "Does this need to remember anything between conversations, or is each use fresh?"

---

## When the user is a non-developer and seems intimidated

- Avoid any technical terms until they show comfort with them.
- Use analogies: "Think of it like teaching Claude a new habit."
- Reassure: "You don't need to know anything about code — I handle all of that."
- Celebrate small answers: "Perfect, that's exactly the kind of detail I need."

---

## When the user gives a very long answer

Extract the key facts, then reflect back:
> "So if I'm hearing you right, you want Claude to [X], triggered by [Y], and it
> should output [Z]. Does that sound right?"

This validation step reduces rework and builds trust.

---

## Signs you have enough to draft

You're ready to write a draft when you know:
1. ✅ What Claude should DO (the action)
2. ✅ What triggers it (a phrase, a file type, a context)
3. ✅ What the user gives Claude (input)
4. ✅ What Claude gives back (output)

Edge cases and external tools are nice-to-have — start drafting even without them, and
note them as TODOs in the skill for later.
