---
name: SKILL_NAME_SLUG
description: >
  VERB_FIRST_ACTION_SENTENCE.
  Use whenever the user says TRIGGER_PHRASES or when TRIGGER_CONTEXT.
  Activate proactively when PROACTIVE_CONTEXT — don't wait for an explicit ask.
---

# SKILL_DISPLAY_NAME

SHORT_PLAIN_ENGLISH_DESCRIPTION (1–2 sentences for context).

---

## What This Skill Does

PARAGRAPH_EXPLAINING_THE_SKILL_IN_PLAIN_ENGLISH. Write as if explaining to a
colleague who isn't technical. Focus on the outcome the user gets, not the mechanics.

---

## Step-by-Step Workflow

1. **Receive input** — DESCRIBE_WHAT_CLAUDE_RECEIVES
2. **STEP_2_VERB** — STEP_2_DESCRIPTION
3. **STEP_3_VERB** — STEP_3_DESCRIPTION
4. **Deliver output** — DESCRIBE_WHAT_CLAUDE_RETURNS_TO_USER

<!-- Add or remove steps as needed. Keep steps concrete and action-oriented. -->

---

## Input & Output

**Input:** WHAT_THE_USER_PROVIDES (e.g. pasted text, uploaded file, a URL, nothing)

**Output:** WHAT_CLAUDE_PRODUCES (e.g. a .docx file, a response in chat, a summary)

---

## Examples

**Example 1:**

Input:
```
PASTE_EXAMPLE_INPUT_HERE
```

Output:
```
PASTE_EXAMPLE_OUTPUT_HERE
```

<!-- Add a second example if the skill has meaningfully different use cases -->

---

## Edge Cases & Guardrails

- If the input is EDGE_CASE_1, then WHAT_CLAUDE_SHOULD_DO.
- If the input is EDGE_CASE_2, warn the user and ask for clarification.
- This skill should NOT be used for OUT_OF_SCOPE_CASE.

<!-- Remove this section if there are no meaningful edge cases -->

---

## Tool Requirements

<!-- Remove this section if the skill doesn't need external tools -->

- **Tool name**: WHY_IT_S_NEEDED
- **Fallback**: WHAT_TO_DO_IF_TOOL_UNAVAILABLE
